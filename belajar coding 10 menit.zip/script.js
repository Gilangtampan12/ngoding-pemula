// Animasi Scroll
document.addEventListener("scroll", function() {
  const sections = document.querySelectorAll("section");
  sections.forEach(section => {
    if (isInViewport(section)) {
      section.classList.add("animate");
    }
  });
});

// Mengecek apakah elemen terlihat di viewport
function isInViewport(el) {
  const rect = el.getBoundingClientRect();
  return rect.top >= 0 && rect.bottom <= window.innerHeight;
}

// Sticky Navbar
window.onscroll = function() {
  const navbar = document.querySelector("header");
  if (window.scrollY > 50) {
    navbar.classList.add("sticky");
  } else {
    navbar.classList.remove("sticky");
  }
};